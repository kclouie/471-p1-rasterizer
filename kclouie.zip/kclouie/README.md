Kalea Louie
----------------

Colors for Mode 2: Green and Blue

Code Citations:
----------------
"Mathematics for Computer Graphics - Barycentric Coordinates". Dr. Philippe B. Laval. November 10, 2003.

"Chapter 1: The 2D Image domain" - unknown (taken from polylearn)

